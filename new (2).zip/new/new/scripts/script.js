/* City Construction Dashboard – client logic */
/* eslint-env jquery */
/* @ai-assist ChatGPT generated modular fetch + rule logic. ↂ AI-generated code ends. */

$(async function () {
  /* ---------- CONFIG ---------- */
  const WEATHER_KEY = window.env?.WEATHER_API_KEY || "YOUR_OPENWEATHER_KEY";
  const API_ROOT    = "/api";           // your Azure Function or PHP endpoint

  /* ---------- LOAD PROJECTS ---------- */
  async function fetchProjects() {
    // Example response shape expected from backend:
    // [{id:1,name:"Quayside Tower",city:"Newcastle",lat:54.97,lng:-1.61,
    //   resources:["crane","digger"] , description:"High-rise build"}]
    return fetch(API_ROOT + "/projects")
           .then(r => r.json())
           .catch(() => []); // fall back to empty list on error
  }

  function renderProjects(list) {
    const $tbody = $("#projects-table tbody").empty();
    list.forEach(p => {
      $("<tr>")
        .attr("data-id", p.id)
        .data("project", p)
        .append(`<td>${p.name}</td>`)
        .append(`<td>${p.city}</td>`)
        .append(`<td>${p.resources.join(", ")}</td>`)
        .appendTo($tbody);
    });
  }

  /* ---------- WEATHER + AQI ---------- */
  async function fetchWeather(lat, lon) {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${WEATHER_KEY}&units=metric`;
    return fetch(url).then(r => r.json());
  }
  async function fetchAQI(lat, lon) {
    const url = `https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${WEATHER_KEY}`;
    return fetch(url).then(r => r.json());
  }
  async function fetchForecast(lat, lon) {
    const url = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${WEATHER_KEY}&units=metric`;
    return fetch(url).then(r => r.json());
  }

  const AQI_TEXT = ["", "Good", "Fair", "Moderate", "Poor", "Very Poor"];

  function buildRecommendation(proj, weather, aqi) {
    const res   = proj.resources;
    const desc  = weather.weather[0].description;
    const wind  = weather.wind.speed * 2.237; // m/s → mph
    const rain  = weather.rain?.["1h"] || 0;
    const aqiIdx= aqi.list[0].main.aqi;

    let out = [];

    // ---- Weather rules ----
    if (wind > 20 && res.includes("crane"))
      out.push("⚠️  Wind > 20 mph – postpone crane operations.");
    if (rain > 0 && /heavy|very heavy|extreme/i.test(desc) &&
        (res.includes("digger") || res.includes("dumper")))
      out.push("⚠️  Heavy rain – digging & earth moving likely delayed.");

    // ---- Air-quality rules ----
    if (res.some(r => ["digger","dumper"].includes(r))) {
      if (aqiIdx <= 2)
        out.push(`✅  Air quality ${AQI_TEXT[aqiIdx]} – earth-moving OK.`);
      else
        out.push(`⚠️  Air quality ${AQI_TEXT[aqiIdx]} – avoid dust-raising work.`);
    }

    return out.length ? out.join("<br>") :
           "✅  No weather or air-quality issues detected.";
  }

  function updateRealtimeUI(weather, aqi) {
    $("#weather-current")
      .html(`🌡️ ${weather.main.temp.toFixed(1)} °C &nbsp;|&nbsp; ${weather.weather[0].description}`);
    const idx = aqi.list[0].main.aqi;
    $("#aqi-current").html(`AQI ${idx} – ${AQI_TEXT[idx]}`);
  }

  function updateForecastUI(list) {
    const html = list.slice(0, 7*8)   // 7 days * 8×3-h slots
      .filter((_,i) => i%8===0)       // midday snapshots
      .map(item => {
        const d = new Date(item.dt * 1000);
        return `<div class="forecast-item">
                  <strong>${d.toLocaleDateString()}</strong>
                  <span>${item.main.temp.toFixed(0)} °C</span>
                  <span>${item.weather[0].main}</span>
                </div>`;
      }).join("");
    $("#weather-forecast").html(html);
  }

  /* ---------- ROW CLICK HANDLER ---------- */
  $("#projects-table").on("click","tr", async function () {
    const proj = $(this).data("project");

    // Map
    window.setProjectLocation(proj.lat, proj.lng, proj.name);

    // Details
    $("#project-name").text(proj.name);
    $("#project-description").text(proj.description);

    // Weather + AQI
    const [weather, aqi] = await Promise.all([
      fetchWeather(proj.lat, proj.lng),
      fetchAQI(proj.lat, proj.lng),
    ]);
    updateRealtimeUI(weather, aqi);
    $("#rec-output").html(buildRecommendation(proj, weather, aqi));

    // Prefetch forecast
    $("#btn-forecast").prop("disabled", false).data("proj", proj);
  });

  /* ---------- Forecast button ---------- */
  $("#btn-forecast").on("click", async function () {
    const proj = $(this).data("proj");
    if (!proj) return;
    const forecast = await fetchForecast(proj.lat, proj.lng);
    updateForecastUI(forecast.list);
    $("#weather-forecast").toggle();
  });

  /* ---------- Bootstrap ---------- */
  renderProjects(await fetchProjects());
});
